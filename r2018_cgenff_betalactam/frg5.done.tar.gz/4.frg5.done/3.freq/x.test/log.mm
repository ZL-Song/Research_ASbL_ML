1
                 Chemistry at HARvard Macromolecular Mechanics
           (CHARMM) - Developmental Version 42b2   February 15, 2018            
       Copyright(c) 1984-2014  President and Fellows of Harvard College
                              All Rights Reserved
  Current operating system: Linux-3.10.0-693.21.1.el7.x86_64(x86_64)@login03.   
                 Created on  3/15/19 at 15:57:31 by user: zilins      

            Maximum number of ATOMS:    360720, and RESidues:      120240
 RDTITL> * PROJ FORCE FIELD DEV - SMALL DRUG MOLECULES
 RDTITL> * MOLECULAR VIBRATION FREQUENCY OPTIMIZATION
 RDTITL> * BASING ON GAUSSIAN MP2/6-31GD VIRBATIONAL SPECTRUM TO GENERATE QM TARGET DATA
 RDTITL> * USAGE: "important output file name"
 RDTITL> *   CHARMM < VIB_FREQ.INP > LOG.MM
 RDTITL> * ZILIN SONG, 18 JAN 2018
 RDTITL> *
  
 CHARMM>     
  
 CHARMM>     IOFOrmat EXTEented
 MISCOM> Expanded I/O format is used.
  
 CHARMM>     BOMLev -1
  
 CHARMM>     FASTer 1
 MISCOM> FAST option: ON (generic fast routines)
  
 CHARMM>     PRNLev 0

 DRUDES PARTICLES WILL BE GENERATED AUTOMATICALLY FOR ALL ATOMS WITH NON-ZERO ALPHA
 Thole-type dipole screening, Slater-Delta shape {S(u) = 1 - (1+u/2)*exp(-u)}, default radius =  1.300000
 WARNING from DECODF -- Zero length string being converted to 0.

      ***** LEVEL  0 WARNING FROM <PARRDR> *****
      ***** NO MATCH FOR NBFIX
      ******************************************
      BOMLEV ( -2) IS NOT REACHED. WRNLEV IS  5

 PARRDR> WARNING: ATOMS IN NBFIX O        CLGR1      -0.20000   3.40000 DONT EXIST

      ***** LEVEL  0 WARNING FROM <PARRDR> *****
      ***** NO MATCH FOR NBFIX
      ******************************************
      BOMLEV ( -2) IS NOT REACHED. WRNLEV IS  5

 PARRDR> WARNING: ATOMS IN NBFIX ON1      CLGR1      -0.20000   3.40000 DONT EXIST

      ***** LEVEL  0 WARNING FROM <PARRDR> *****
      ***** NO MATCH FOR NBFIX
      ******************************************
      BOMLEV ( -2) IS NOT REACHED. WRNLEV IS  5

 PARRDR> WARNING: ATOMS IN NBFIX ON1C     CLGR1      -0.20000   3.40000 DONT EXIST

      ***** LEVEL  0 WARNING FROM <PARRDR> *****
      ***** NO MATCH FOR NBFIX
      ******************************************
      BOMLEV ( -2) IS NOT REACHED. WRNLEV IS  5

 PARRDR> WARNING: ATOMS IN NBFIX OC2D1    CLGR1      -0.20000   3.40000 DONT EXIST

      ***** LEVEL  0 WARNING FROM <PARRDR> *****
      ***** NO MATCH FOR NBFIX
      ******************************************
      BOMLEV ( -2) IS NOT REACHED. WRNLEV IS  5

 PARRDR> WARNING: ATOMS IN NBFIX S        CLGR1      -0.38000   3.83000 DONT EXIST

      ***** LEVEL  0 WARNING FROM <PARRDR> *****
      ***** NO MATCH FOR NBFIX
      ******************************************
      BOMLEV ( -2) IS NOT REACHED. WRNLEV IS  5

 PARRDR> WARNING: ATOMS IN NBFIX HS       CLGR1      -0.20000   2.82000 DONT EXIST
 RDCMND: can not substitute energy "?NATC""
 RDCMND: can not substitute energy "?NATC""
 RDCMND: can not substitute energy "?WRNLEV""

   >>>>>> Entering MOLVIB module of CHARMM <<<<<<


     MLVCOM: CHARMM RTF/PSF will be used inside MOLVIB


     MLVCOM: CHARMM second derivatives will be
      evaluated and passed directly to MOLVIB

  MOLVIB dimensions have been set

   NQ,NIC,NIC0,NAT =      24      24      34      -1
   IZMAX,MAXSYB,NGMAX,NBLMAX =      10      24      24      24

  The maximum dimension has been set to NQM =          34

 FASTST> Second derivatives are not supported with FAST option.
         Using generic routines (enables second derivatives).

   CHARMM cartesian coordinates passed to MOLVIB

    Atom #       X         Y         Z       MASS  
     1      0.76900   0.21300  -0.00600  12.01100
     2      0.15900   1.33600   0.00100  14.00700
     3     -1.20700   1.14300   0.00600  12.01100
     4     -1.63800  -0.12100   0.01200  12.01100
     5     -0.26400  -1.19500  -0.00800  32.06000
     6      2.13100   0.08600  -0.07100  14.00700
     7     -1.84400   2.00600   0.01200   1.00800
     8     -2.64100  -0.49200   0.02800   1.00800
     9      2.60900   0.94100   0.12100   1.00800
    10      2.52900  -0.70200   0.39100   1.00800

   Atomic masses passed to MOLVIB:

  12.01100 14.00700 12.01100 12.01100 32.06000 14.00700  1.00800  1.00800
   1.00800  1.00800 12.01100 14.00700 12.01100 12.01100 32.06000 14.00700
   1.00800  1.00800  1.00800  1.00800 12.01100 14.00700 12.01100 12.01100
  32.06000 14.00700  1.00800  1.00800  1.00800  1.00800



      MOLVIB : PROGRAM FOR MOLECULAR VIBRATIONAL SPECTROSCOPY



 GFX      0    0    0    0


   SELECTED OPTION : VIBRATIONAL EIGENVALUE PROBLEM IN CARTESIAN COORDINATES


 PRNT     0    0    0    0
  U matrix has been read : INU =            1

 The PED cutoff will be CUTPED =   0.100

       Starting FX diagonalization 


  **** Found            5   negative eigenvalues ****


    Symbolic PED matrix [%] (sorted)

   1      0.0   dNH2C1   103.
   2    186.7   wagC1     67.   5rTor_    46.   wagN6    -43.   dNH2C1    32.

   3    280.0   rocC1     91.
   4    457.2   wagN6     78.   5rTor     65.   dNH2C1   -40.   5rTor_    23.
                wagC1    -19.
   5    515.3   5rDef     34.   sC1-N6    21.   5rTor     17.   5rDef_    11.

   6    563.5   wagN6     39.   5rTor     32.   5rTor_    15.
   7    660.4   sC1-S5    31.   sC1=N2    19.   sC1-N6    16.   5rDef_    13.
                sC4-S5    12.
   8    702.6   wagC4     59.   wagC3     37.
   9    749.1   sC4-S5    36.   sC1-S5    29.   5rDef     16.   5rDef_    14.

  10    794.8   wagC3     39.   wagC1     35.   wagN6     20.   wagC4     12.

  11    829.0   wagC4     35.   wagC3     30.   wagC1     17.   dNH2C1    16.

  12    934.4   sC4-S5    30.   5rDef_    25.   sC3=C4    15.
  13   1056.1   rocC3     58.   rocC4     19.
  14   1074.7   sN2-C3    27.   rocC4     23.   sC3=C4    16.
  15   1240.8   rocN6     41.   rocC4     13.   sC1=N2    12.   5rDef_    11.

  16   1334.1   sC1-N6    32.   rocC3     13.   sC1=N2    13.
  17   1430.6   rocC4     31.   sN2-C3    16.   rocN6     14.
  18   1519.2   sC1=N2    37.   rocN6     29.   sN2-C3    13.
  19   1560.8   sC3=C4    42.   5rDef     18.   sN2-C3    12.
  20   1792.3   scsN6     95.
  21   3136.4   sC4-H8    99.
  22   3184.9   sC3-H7    99.
  23   3336.0   sN6-H10   53.   sN6-H9    46.
  24   3416.8   sN6-H9    54.   sN6-H10   46.
 GFX option finished

      $$$$$$  New timer profile Local node$$$$$

      Nonbond force                   0.00 Other:            0.00
         Bond energy                     0.00 Other:            0.00
         Angle energy                    0.00 Other:            0.00
         Dihedral energy                 0.00 Other:            0.00
         Restraints energy               0.00 Other:            0.00
      INTRNL energy                   0.00 Other:            0.00
      Comm energy                     0.00 Other:            0.00
      Comm force                      0.00 Other:            0.00
   Energy time                     0.00 Other:            0.00
 Total time                      0.71 Other:            0.71

         $$$$$$  Average   profile $$$$$

      Nonbond force                   0.00 Other:            0.00
         Bond energy                     0.00 Other:            0.00
         Angle energy                    0.00 Other:            0.00
         Dihedral energy                 0.00 Other:            0.00
         Restraints energy               0.00 Other:            0.00
      INTRNL energy                   0.00 Other:            0.00
      Comm energy                     0.00 Other:            0.00
      Comm force                      0.00 Other:            0.00
   Energy time                     0.00 Other:            0.00
 Total time                      0.71 Other:            0.71
