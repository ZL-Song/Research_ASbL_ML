import subprocess as subp
import sys

# Molecular Vibrational Spectrum test for pnm part III
# This script is used for extracting CHARMM output log file to FREQ.ENE.
# Could not be called by CHARMM script
# NOTE:     
#       qm molvib output log must be named as "log.qm"
#       mm molvib output log must be named as "log.mm"
# 
# Zilin Song, 27 DEC 2018
# 

# check if str s is a number
def is_number(s) -> bool:
    try:
        float(s)
        return True
    except ValueError:
        return False
        
# Extract CHARMM log file with the name, file_name. this method returns a list with frequencies
def extract_log(
    file_name :str
    ) -> (list, list):

    switch_start = False
    txt_freq_list = []
    freq_list = []
    txt_freq_NICs_list = []
    
    with open(file_name, 'r') as fr:

        line = fr.readline()
        
        while line:
            words = line.split()

            # note: interested output region could have 
            #     1, empty lines; 2, 1 frequency discription on multiple lines.
            # sample of output line are supposed to be processed:
            # 10    745.5   sC4-S5    49.   5rDef     19.   5rDef_    17.
            if switch_start == True and line != "\n" and is_number(words[0]):
                txt_freq_list.append(words[1])
                temp_nic_list = []
                for i in range(0, len(words)):
                    if i == 2 or i == 4 or i == 6:
                        temp_nic_list.append(words[i])
                txt_freq_NICs_list .append(temp_nic_list[:])
                temp_nic_list.clear()

            # check if entered interested output region:
            # Symbolic PED matrix [%] (sorted)
            # ( empty line )
            #    interested until ...
            # GFX option finished.
            if line.startswith("    Symbolic PED matrix [%] (sorted)"):
                switch_start = True         # entered interested region
                line = fr.readline()        # skip following empty line
            elif line.startswith(" GFX option finished"):
                switch_start = False        # reached end of interested region
            else:
                pass
            
            line = fr.readline()
    
    for txtFr in txt_freq_list:
        freq_list.append(float(txtFr))

    return freq_list, txt_freq_NICs_list

def main():

    qm_molvib_file = "log.qm"
    qm_freq_list, qm_nic_lists = extract_log(qm_molvib_file)

    mm_molvib_file = "log.mm"
    mm_freq_list, mm_nic_lists = extract_log(mm_molvib_file)

    freq_diff_abs = 0.
    freq_diff = 0.
    similarity_score_list = []
    deviation_score_list = []

    # write freq.ene
    with open("freq.ene", 'w') as fw:

        # check if no. mm freq == no. qm freq
        # if not exit(): len(mm_freq_list) == len(qm_freq_list)
        if len(qm_freq_list) != len(mm_freq_list):
            fw.write("\n\nIllegal frequency list: no. qm freq != no. mm freq.")
            exit()
        
        # deal with each freq respectively in qm and mm
        for flag in range(0, len(qm_freq_list)):
            # calc frequencies value deviation.
            freq_diff_abs += abs(mm_freq_list[flag] - qm_freq_list[flag])
            freq_diff += mm_freq_list[flag] - qm_freq_list[flag]

        # compare NICs in each frequency
        # similarity score + 1 if same NIC entry is found in same frequency
        # .......... ..... + 3 if frequency are close between mm and qm
        # deviation score = (no. qm NICs @ frequency) - similarity score
        for nics_list_flag in range(0, len(qm_freq_list)):
            #print(qm_nic_lists[nics_list_flag])
            qm_nics = qm_nic_lists[nics_list_flag]
            mm_nics = mm_nic_lists[nics_list_flag]
            simil_score = 0
            for q_nic in qm_nics:
                for m_nic in mm_nics:
                    if q_nic == m_nic:
                        simil_score += 1
            devia_score = int(len(qm_nics) - simil_score)
            deviation_score_list.append(devia_score)
            similarity_score_list.append(simil_score)
        simil_sum = 0
        for s in similarity_score_list:
            simil_sum += s
        for s in range(0, len(qm_freq_list)):
            if qm_freq_list[s] - mm_freq_list[s] <= qm_freq_list[s] * 0.3 / round(qm_freq_list[s] / 100):
                #print('{0}\t{1}\t{2}'.format(qm_freq_list[s], mm_freq_list[s], qm_freq_list[s] * 0.3 / round(qm_freq_list[s] / 100)))
                simil_sum += 3
        simil_average = simil_sum / len(similarity_score_list) * 100
        devia_sum = 0
        for d in deviation_score_list:
            devia_sum += d
        devia_average = devia_sum / len(deviation_score_list) * 100
        
        # calc rmsd
        avg_abs_diff = round(freq_diff_abs / len(mm_freq_list), 4)
        freq_diff_rmsd = 0.
        freq_diff_sd = 0.
        for flag in range(0, len(mm_freq_list)):
            freq_diff_sd += (abs(mm_freq_list[flag] - avg_abs_diff)) ** 2
        freq_diff_rmsd = freq_diff_sd ** 0.5

        # check if mm frequencies are distributed in the qm frequencies range (lowest to highest).
        first_qm_freq = qm_freq_list[0]
        first_mm_freq = mm_freq_list[0]
        last_qm_freq = qm_freq_list[len(qm_freq_list) - 1]
        last_mm_freq = mm_freq_list[len(mm_freq_list) - 1]
        is_good_result = False
        if     abs(first_qm_freq - first_mm_freq) <= 30 \
           and abs((last_mm_freq - first_mm_freq) - (last_qm_freq - first_qm_freq)) <= 200:
            is_good_result = True
        else:
            is_good_result = False

        # write header
        fw.write('{0:8}\t{1:8}\t{2:9}\t{3:9}\n'.format('qm_freq', 'mm_freq', 'similarty', 'deviation'))
        
        # write output content
        for i in range(0, len(qm_freq_list)):
            fw.write('{0:8}\t{1:8}\t{2:9}\t{3:9}\n'.format(qm_freq_list[i], mm_freq_list[i], similarity_score_list[i], deviation_score_list[i]))
            
        # write summary
        fw.write('&& DIFF: {0:8.4f} Abs(Diff): {1:8.4f} RMSD(diff): {2:8.4f}\n'.format(freq_diff, freq_diff_abs, freq_diff_rmsd))
        fw.write('|| Range?: {0} SimilScore: {1:.2f} DeviaScore: {2:.2f}'.format(is_good_result, simil_average, devia_average))
        
if __name__ == "__main__":
    main()