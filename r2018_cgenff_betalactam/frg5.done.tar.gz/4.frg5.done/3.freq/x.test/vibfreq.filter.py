def main():
    fw = open('vibfreq.scan.filtered.py.out', 'w')
    with open('vibfreq.scan.py.out') as fr:
        line = fr.readline()
        while line:
            words = line.split()
            if len(words) >= 7 and words[6].startswith('simi_s^:'):
                fw.write(line)
            line = fr.readline()



if __name__ == "__main__":
    main()