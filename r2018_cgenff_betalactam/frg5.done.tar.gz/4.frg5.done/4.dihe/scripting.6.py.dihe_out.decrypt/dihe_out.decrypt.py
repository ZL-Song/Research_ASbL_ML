# dihedral test for cephalosporins.
# This script would:
#       1. Decript the output file from dihe.scan.py
# 
# usage:
#       python dihe_out.decrypt.py file_name
# NOTE:
#       file_name: name of output file
# Zilin Song, 18 FEB 2O19
# 

import subprocess as subp
import sys
import os

out_name = sys.argv[1]

no_dihes = 0
dihe_list = []
dihe_name_list = []
steps = 0
perstep = 0

out_file = open(out_name, 'r')
initread = out_file.readline()
while initread:
    initread = str(initread)
    if initread.startswith('Original test Set:'):
        # get the number of dihedrals
        no_dihes = len(str(initread.split(':')[1]).replace('[', '').replace(']', '').replace('\t', '').replace(' ', '').replace('\n', '').split(','))
        dihe_list = str(initread.split(':')[1]).replace('[', '').replace(']', '').replace('\t', '').replace(' ', '').replace('\n', '').replace('\'', '').split(',')
    if initread.startswith('Test Dihedrals:'):
        dihe_name_list = str(initread.split(':')[1]).replace('[', '').replace(']', '').replace('\t', '').replace(' ', '').replace('\n', '').replace('\'', '').split(',')
    if initread.startswith('Steps for scanning:'):
        steps = int(initread.split()[3])    
    if initread.startswith('Step size for scan:'):
        perstep = float(initread.split()[4]) / steps
        break
    initread = out_file.readline()  

print(no_dihes)
print(dihe_list)
print(dihe_name_list)
print(steps)
print(perstep)

# NOTE: write the following files: dihe_n/dihe_n@0.000.out
#1	|gPesSum: 657.928200	|gAbsSum: 677.310400	|sumDihe_n: [-354.2864, -303.6418]	absSumDihe_n: [373.0076, 304.3028]|testSet: [-0.68, -0.68]
outdir = 'result.decrypted'
subp.call('mkdir {0}'.format(outdir), shell=True)
for noDihe in range(0, no_dihes):
    subp.call('mkdir {0}/{1}'.format(outdir, dihe_name_list[noDihe]), shell=True)
    for i in range(-steps, steps + 1):

        out_file = open(out_name, 'r')
        dihe = round(float(dihe_list[noDihe]) + i * perstep, 3)
        output = open('{0}/{1}/{2:0.2}'.format(outdir, dihe_name_list[noDihe], dihe), 'w')
        
        lines = out_file.readlines()
        for line in lines:
            words = line.split('|')
            if len(words) == 5 and str(words[1]).startswith('gPesSum:'):
                currDiheList = words[4].split(':')[1].replace(' ', '').replace('[', '').replace(']', '').replace('\n', '').split(',')
                #print(currDiheList)
                if currDiheList[noDihe] == str(dihe):
                    output.write('{0}'.format(line))
        out_file.close()
