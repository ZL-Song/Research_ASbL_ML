import mdtraj as mdtraj

qm_pdb = mdtraj.load('cflt.mp2.pdb')
mm_pdb = mdtraj.load('cflt_mmmini.pdb')

mm_pdb.superpose(qm_pdb,  atom_indices=[16, 17, 18, 19])

mm_pdb.save('cflt.superposed.pdb')