import subprocess as subp


angsteps = [0.1, 0.3, 0.5, 0.7, 0.9, 1.1, 1.3, 1.5, 2.0, 2.5, 3.0]
lensteps = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15]

targetlist = []

for a in lensteps:
    for b in angsteps:
        targetlist.append([a/5, b/5])

runCount = 0
for target in targetlist:
    subp.call('mkdir -p inputs/{0}.{1}/'.format(target[0], target[1]), shell=True)
    subp.call('cp -r equi.scan.py inputs/{0}.{1}/equi.scan.py'.format(target[0], target[1]), shell=True)
    subp.call('cp -r sh.job inputs/{0}.{1}/sh.job'.format(target[0], target[1]), shell=True)

    subp.call("sed -i -e 's/len_perstep = 2####/len_perstep = {0}/g' inputs/{0}.{1}/equi.scan.py".format(target[0], target[1]), shell=True)
    subp.call("sed -i -e 's/ang_perstep = 2####/ang_perstep = {1}/g' inputs/{0}.{1}/equi.scan.py".format(target[0], target[1]), shell=True)

    subp.call("sed -i -e 's/###   ###/python inputs\/{0}.{1}\/equi.scan.py/g' inputs/{0}.{1}/sh.job".format(target[0], target[1]), shell=True)

    subp.call('sbatch inputs/{0}.{1}/sh.job'.format(target[0], target[1]), shell=True)

    runCount += 1
    print('{0} | {1}\n'.format(runCount, len(targetlist)))

print('\nJob Submitted: {0}\n\nDone.\n'.format(runCount))
