# Proj Force Field Dev - cephalosporins
# Dihedral angle force constants: Fragment III P 0.
# Decrpt Gaussian output for HF pes extract.
# So Far only Dihedral & Angles supports
# Usage:
#       python all.qmpes.extract.py qm_source_data outputdir
# qm_source_data:
#   the qm_source_data contains all gaussian outputs, .log as output format.
#   will map all subdirectories, so a root qm_source_data is suggested.
# NOTE:
#   method write_ic_log():
#   assigning atom symbol for each atom number.
# Zilin Song, 17 Jan 2019
#  

import os
import os.path
import sys

#interested qm_source_data
source_data = sys.argv[1]

# main
def main():

    file_list = []

    # grab all gaussian.log File.
    for root, dirs, files in os.walk(source_data):
        for f in files:
            if f.endswith('.out'):
                file_list.append('{0}/{1}'.format(root, f))
            else:
                pass

    # decrypt each log file 1 by 1
    fo = open('log.out', 'w')
    
    print('\n************************************************************')
    for f in file_list:
        lowest = 999.9999
        goodline = 'none'
        goodfile = 'none'
        totalTest = 0
        for l in open(f, 'r').readlines():
            words = l.split()
            if len(words) > 15 and words[2] == '|globalMin:':
                totalTest +=1
                sumAng = float(words[14].replace('|', '')) + float(words[16].replace('|', '')) *5
                if sumAng < lowest:
                    lowest = sumAng
                    goodline = l
                    goodfile = f
        print('{1} \t{2}\t|crtDiff:{0}'.format(goodline.split('|crtDiff:').pop(), goodfile, totalTest))
        fo.write('{1}  \t{2}|crtDiff:{0}'.format(goodline.split('|crtDiff:').pop(), goodfile, totalTest))

    print('\n************************************************************\n')

    

if __name__ == "__main__":
    main()
