# call charmm script 'extract.qm.pdb.inp' to recursively remove non-QM atoms for each pathway 
# Zilin Song
# 

import subprocess as subp

def main():
    # list of pathids => 2d-list
    path_list = [
        ('reactant', [112,326,634,1570,1828,1966]), # reactant pathids
        ('ts',       [651,713,870,1267,1376,1826]), # ts pathids
        ('nhinter',  [390,663,728,1178,1221,1453]), # nhinter pathids
    ]
    # no. replicas
    rep_count = 50

    for state, pathids in path_list:

        for pathid in pathids:
            
            for rep in range(1, rep_count+1):
                
		# ## sccdftb
                # if state == 'reactant':
                #     stt = '5.0.reactant'
                # elif state == 'ts':
                #     stt = '5.1.ts'
                # elif state == 'nhinter':
                #     stt = '5.2.nhinter'
                # else:
                #     pritn('wrong state specified.\n')
                # cor_dir = '../../../' + stt + '/3.path.acylation/2.path.extract/path.' + str(pathid) + '.dat/r' + str(rep)
                # pdb_dir = 'sccdftb/{0}/path.{1}.dat/r{2}'.format(state.split('.').pop(), str(pathid), str(rep))
                # subp.call('mkdir -p sccdftb/{0}/path.{1}.dat/'.format(state.split('.').pop(), str(pathid)), shell=True)
                
                # ## dft/631G
                if state == 'reactant':
                    stt = '5.3.reactant.b3lyp'
                elif state == 'ts':
                    stt = '5.4.ts.b3lyp'
                elif state == 'nhinter':
                    stt = '5.5.nhinter.b3lyp'
                else:
                    print('wrong state specified.\n')

                cor_dir = '../../../' + stt + '/3.path.extract/path.' + str(pathid) + '.dat/r' + str(rep)
                pdb_dir = 'b3lyp/{0}/path.{1}.dat/r{2}'.format(state.split('.').pop(), str(pathid), str(rep))
                subp.call('mkdir -p b3lyp/{0}/path.{1}.dat/'.format(state.split('.').pop(), str(pathid)), shell=True)
                

                subp.call('/hpc/applications/charmm/c41b1/charmm_m_mpich inname:{0} outname:{1} < extract.qm.pdb.inp'.format(cor_dir, pdb_dir), shell=True)




if __name__ == "__main__":
    main()
